import struct,gzip,json,sys
class NBT:
 def __init__(self,b):self.b=b;self.p=0
 def read(self,n):r=self.b[self.p:self.p+n];self.p+=n;return r
 def num(self,f):return struct.unpack('>'+f,self.read(struct.calcsize('>'+f)))[0]
 def string(self):return self.read(self.num('H')).decode('utf8')
 def tag(self,t):
  if 1<=t<=6:return self.num({1:'b',2:'h',3:'i',4:'q',5:'f',6:'d'}[t])
  if t==7:return list(self.read(self.num('i')))
  if t==8:return self.string()
  if t==9:
   k=self.num('B');return [self.tag(k) for _ in range(self.num('i'))]
  if t==10:
   r={}
   while True:
    k=self.num('B')
    if not k:return r
    name=self.string();r[name]=self.tag(k)
  if t in (11,12):return [self.num('i' if t==11 else 'q') for _ in range(self.num('i'))]
  raise ValueError(t)
def load(path):
 b=open(path,'rb').read()
 if b[:2]==b'\x1f\x8b':b=gzip.decompress(b)
 n=NBT(b);t=n.num('B');n.string();return n.tag(t)
if __name__=='__main__':print(json.dumps(load(sys.argv[1]),indent=2))
