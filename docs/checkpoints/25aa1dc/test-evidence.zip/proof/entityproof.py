from pathlib import Path
import zlib,struct,json,sys,uuid
sys.path.insert(0,'work');from readnbt import NBT
def residents(root):
 result=[]
 for path in Path(root).glob('entities/r.*.mca'):
  b=path.read_bytes()
  for i in range(1024):
   off=int.from_bytes(b[i*4:i*4+3],'big')*4096
   if not off:continue
   size=int.from_bytes(b[off:off+4],'big');typ=b[off+4];raw=b[off+5:off+4+size]
   if typ==2:raw=zlib.decompress(raw)
   elif typ!=3:raise ValueError(typ)
   r=NBT(raw);t=r.num('B');r.string();d=r.tag(t)
   for e in d.get('Entities',[]):
    if e.get('id','').startswith('kingdom_smp:'):
     uid=str(uuid.UUID(bytes=struct.pack('>4i',*e['UUID'])))
     result.append({'type':e['id'],'uuid':uid,'name':e.get('CustomName')})
 return sorted(result,key=lambda e:e['uuid'])
if __name__=='__main__':print(json.dumps({p:residents(p) for p in sys.argv[1:]},indent=2))
