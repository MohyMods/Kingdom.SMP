from pathlib import Path
import sys,json,hashlib,uuid,struct
sys.path.insert(0,'work')
from readnbt import load
from entityproof import residents
root=Path('work/market-live-server/royal-final-world')
def proof():
 d={'authority':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((root/'data').glob('kingdomsmp*')) if p.is_file()},'npcs':residents(root),'players':{}}
 for name,u in [('Dev','380df991-f603-344c-a090-369bad2a924a'),('DevTwo','b739a3a2-f48b-36f5-b02c-db6061f960a7')]:
  n=load(root/'playerdata'/f'{u}.dat');d['players'][name]={'items':n.get('Inventory',[]),'receipt':n.get('NeoForgeData',n.get('neoforge:attachments',{}))}
 e=load(root/'data/kingdomsmp_economy.dat');d['history']=e['history'];d['pending']=e.get('pending');return d
if __name__=='__main__':Path(sys.argv[1]).write_text(json.dumps(proof(),indent=2)+'\n')
